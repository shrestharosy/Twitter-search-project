var appsetings = {
    consumerkey: '<consumerkey here>',
    consumersecret:'<consumersecret here>',    
    bearertoken:''
    //receive by making request to twitter
};
//Twitter Search Project Task
module.exports = appsetings;